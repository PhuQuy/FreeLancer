package com.spring.entity;

public class Views {
    public static class Public {}
}
